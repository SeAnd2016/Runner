package core;

public class A {
	
	public static String s = "Testing JUNit 4.12";
    public static void main( String[] args )
    {
        System.out.println(s);
    }
}